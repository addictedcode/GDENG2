// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "FileIOBlueprintLibrary.generated.h"

/**
 * 
 */
UCLASS()
class GDENG2_API UFileIOBlueprintLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
public:
	UFUNCTION(BlueprintCallable, Category = "File I/O")
		static bool LoadFileToString(FString& result, FString filepath);

	UFUNCTION(BlueprintCallable, Category = "File I/O")
		static bool SaveStringToFile(FString text, FString filepath);

	UFUNCTION(BlueprintCallable, Category = "File I/O")
		static void OpenFileDialog(const FString& DialogTitle, const FString& DefaultPath, const FString& FileTypes, TArray<FString>& OutFileNames);

	UFUNCTION(BlueprintCallable, Category = "File I/O")
		static void SaveFileDialog(const FString& DialogTitle, const FString& DefaultPath, const FString& FileTypes, TArray<FString>& OutFileNames);

	UFUNCTION(BlueprintCallable, Category = "File I/O")
		static bool LoadYAMLFile(FString filepath);

	UFUNCTION(BlueprintCallable, Category = "File I/O")
		static void SaveSceneToYAMLFile(FString filepath);
};
