// Fill out your copyright notice in the Description page of Project Settings.


#include "FileIOBlueprintLibrary.h"
#include "SceneSerializer.h"
#include "Misc/FileHelper.h"
#include "DesktopPlatform/Public/IDesktopPlatform.h"
#include "DesktopPlatform/Public/DesktopPlatformModule.h"
#include "Engine/GameEngine.h"
#include "SlateCore.h"
#include "Framework/Application/SlateApplication.h"

bool UFileIOBlueprintLibrary::LoadFileToString(FString& result, FString filepath)
{
	return FFileHelper::LoadFileToString(result, *filepath);
}

bool UFileIOBlueprintLibrary::SaveStringToFile(FString text, FString filepath)
{
	return FFileHelper::SaveStringToFile(text, *filepath);
}

void UFileIOBlueprintLibrary::OpenFileDialog(const FString& DialogTitle, const FString& DefaultPath, const FString& FileTypes, TArray<FString>& OutFileNames)
{
	void* ParentWindowPtr = FSlateApplication::Get().GetActiveTopLevelWindow()->GetNativeWindow()->GetOSWindowHandle();
	IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
	if (DesktopPlatform)
	{
		uint32 SelectionFlag = 0; //A value of 0 represents single file selection while a value of 1 represents multiple file selection
		DesktopPlatform->OpenFileDialog(ParentWindowPtr, DialogTitle, DefaultPath, FString(""), FileTypes, SelectionFlag, OutFileNames);
	}
}

void UFileIOBlueprintLibrary::SaveFileDialog(const FString& DialogTitle, const FString& DefaultPath,
	const FString& FileTypes, TArray<FString>& OutFileNames)
{
	void* ParentWindowPtr = FSlateApplication::Get().GetActiveTopLevelWindow()->GetNativeWindow()->GetOSWindowHandle();
	IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
	if (DesktopPlatform)
	{
		uint32 SelectionFlag = 0; //A value of 0 represents single file selection while a value of 1 represents multiple file selection
		DesktopPlatform->SaveFileDialog(ParentWindowPtr, DialogTitle, DefaultPath, FString(""), FileTypes, SelectionFlag, OutFileNames);
	}
}

bool UFileIOBlueprintLibrary::LoadYAMLFile(FString filepath)
{
	SceneSerializer serializer;
	return serializer.Deserialize(std::string(TCHAR_TO_UTF8(*filepath)));
}

void UFileIOBlueprintLibrary::SaveSceneToYAMLFile(FString filepath)
{
	SceneSerializer serializer;;
	serializer.Serialize(std::string(TCHAR_TO_UTF8(*filepath)));
}