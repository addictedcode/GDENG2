// Fill out your copyright notice in the Description page of Project Settings.


#include "SceneSerializer.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/StaticMeshActor.h"
#include "Editor/EditorEngine.h"
#include <yaml-cpp/yaml.h>
#include <fstream>

namespace YAML {

	template<>
	struct convert<FVector>
	{
		static Node encode(const FVector& rhs)
		{
			Node node;
			node.push_back(rhs.X);
			node.push_back(rhs.Z);
			node.push_back(-rhs.Y);
			node.SetStyle(EmitterStyle::Flow);
			return node;
		}

		static bool decode(const Node& node, FVector& rhs)
		{
			if (!node.IsSequence() || node.size() != 3)
				return false;

			rhs.X = node[0].as<float>();
			rhs.Z = node[1].as<float>();
			rhs.Y = -node[2].as<float>();
			return true;
		}
	};

	template<>
	struct convert<FVector4>
	{
		static Node encode(const FVector4& rhs)
		{
			Node node;
			node.push_back(rhs.X);
			node.push_back(rhs.Z);
			node.push_back(-rhs.Y);
			node.push_back(rhs.W);
			node.SetStyle(EmitterStyle::Flow);
			return node;
		}

		static bool decode(const Node& node, FVector4& rhs)
		{
			if (!node.IsSequence() || node.size() != 4)
				return false;

			rhs.X = node[0].as<float>();
			rhs.Z = node[1].as<float>();
			rhs.Y = -node[2].as<float>();
			rhs.W = node[3].as<float>();
			return true;
		}
	};

	template<>
	struct convert<FQuat>
	{
		static Node encode(const FQuat& rhs)
		{
			Node node;
			node.push_back(rhs.X);
			node.push_back(rhs.Z);
			node.push_back(-rhs.Y);
			node.push_back(rhs.W);
			node.SetStyle(EmitterStyle::Flow);
			return node;
		}

		static bool decode(const Node& node, FQuat& rhs)
		{
			if (!node.IsSequence() || node.size() != 4)
				return false;

			rhs.X = node[0].as<float>();
			rhs.Z = node[1].as<float>();
			rhs.Y = -node[2].as<float>();
			rhs.W = node[3].as<float>();
			return true;
		}
	};

	Emitter& operator<<(YAML::Emitter& out, const FVector& v)
	{
		out << YAML::Flow;
		out << YAML::BeginSeq << v.X << v.Z << v.Y << YAML::EndSeq;
		return out;
	}

	Emitter& operator<<(YAML::Emitter& out, const FVector4& v)
	{
		out << YAML::Flow;
		out << YAML::BeginSeq << v.X << v.Z << -v.Y << v.W << YAML::EndSeq;
		return out;
	}

	Emitter& operator<<(YAML::Emitter& out, const FQuat& v)
	{
		out << YAML::Flow;
		out << YAML::BeginSeq << v.X << v.Z << -v.Y << v.W << YAML::EndSeq;
		return out;
	}

}

static UStaticMesh* primitive_meshes[5];

SceneSerializer::SceneSerializer()
{
	primitive_meshes[0] = LoadObject<UStaticMesh>(NULL, TEXT("/Engine/BasicShapes/Cube.Cube"), NULL, LOAD_None, NULL);
	primitive_meshes[1] = LoadObject<UStaticMesh>(NULL, TEXT("/Engine/BasicShapes/Plane.Plane"), NULL, LOAD_None, NULL);
	primitive_meshes[2] = LoadObject<UStaticMesh>(NULL, TEXT("/Engine/BasicShapes/Cylinder.Cylinder"), NULL, LOAD_None, NULL);
	primitive_meshes[3] = LoadObject<UStaticMesh>(NULL, TEXT("/GDENG2/BasicShapes/Capsule.Capsule"), NULL, LOAD_None, NULL);
	primitive_meshes[4] = LoadObject<UStaticMesh>(NULL, TEXT("/Engine/BasicShapes/Sphere.Sphere"), NULL, LOAD_None, NULL);
}

SceneSerializer::~SceneSerializer()
{
}

static void SerializeEntity(YAML::Emitter& out, AActor* entity)
{
	out << YAML::BeginMap; // Entity
	out << YAML::Key << "Entity" << YAML::Value << 343434;
	out << YAML::Key << "Tag" << YAML::Value << std::string(TCHAR_TO_UTF8(*entity->GetActorLabel()));

	int mesh_type = 0;
	auto* ent_mesh = ((UStaticMeshComponent*)entity->GetRootComponent())->GetStaticMesh();
	if (ent_mesh)
		for (int i = 0; i < 5; ++i)
		{
			if (ent_mesh == primitive_meshes[i])
			{
				mesh_type = i + 1;
				break;
			}
		}

	out << YAML::Key << "TransformComponent";
	out << YAML::BeginMap; // TransformComponent

	out << YAML::Key << "Translation" << YAML::Value << FVector4(entity->GetActorLocation() / 100.f);
	out << YAML::Key << "Rotation" << YAML::Value << entity->GetActorRotation().Quaternion();
	if (mesh_type == 2)
		out << YAML::Key << "Scale" << YAML::Value << FVector4(entity->GetActorScale3D()) / 10.f;
	else
		out << YAML::Key << "Scale" << YAML::Value << FVector4(entity->GetActorScale3D());

	out << YAML::EndMap; // TransformComponent

	out << YAML::Key << "RendererComponent";
	out << YAML::BeginMap; // RendererComponent

	out << YAML::Key << "Type" << YAML::Value << mesh_type;

	out << YAML::EndMap; // RendererComponent

	if (ent_mesh) {
		auto boxElems = ent_mesh->GetBodySetup()->AggGeom.BoxElems;
		if (boxElems.Num() > 0)
		{
			out << YAML::Key << "BoxColliderComponent";
			out << YAML::BeginMap; // BoxColliderComponent

			out << YAML::Key << "Position" << YAML::Value << boxElems[0].Center;
			out << YAML::Key << "Size" << YAML::Value << FVector(boxElems[0].X, boxElems[0].Y, boxElems[0].Z) / 100.f;

			out << YAML::EndMap; // BoxColliderComponent
		}
	}

	out << YAML::Key << "RigidbodyComponent";
	out << YAML::BeginMap; // RigidbodyComponent

	auto* rbc = ((UStaticMeshComponent*)entity->GetRootComponent());
	int rbc_type = 0;
	if (rbc->IsSimulatingPhysics()) {
		rbc_type = 2;
	}

	out << YAML::Key << "Type" << YAML::Value << rbc_type;
	out << YAML::Key << "IsGravityEnabled" << YAML::Value << rbc->IsGravityEnabled();

	out << YAML::EndMap; // RigidbodyComponent

	out << YAML::EndMap; // Entity
}

void SceneSerializer::Serialize(std::string filepath)
{
	YAML::Emitter out;
	out << YAML::BeginMap;
	out << YAML::Key << "Scene" << YAML::Value << "Untitled";
	out << YAML::Key << "Entities" << YAML::Value << YAML::BeginSeq;

	auto* world = GEditor->GetEditorWorldContext().World();

	TArray<AActor*> FoundActors;
	UGameplayStatics::GetAllActorsOfClass(world, AStaticMeshActor::StaticClass(), FoundActors);

	for (auto* actor : FoundActors)
	{
		SerializeEntity(out, actor);
	}

	out << YAML::EndSeq;
	out << YAML::EndMap;

	std::ofstream fout(filepath);
	fout << out.c_str();
}

bool SceneSerializer::Deserialize(std::string filepath)
{
	YAML::Node data = YAML::LoadFile(filepath);
	if (!data["Scene"])
		return false;

	auto* world = GEditor->GetEditorWorldContext().World();

	TArray<AActor*> FoundActors;
	UGameplayStatics::GetAllActorsOfClass(world, AStaticMeshActor::StaticClass(), FoundActors);

	for (auto* actor : FoundActors)
	{
		world->EditorDestroyActor(actor, true);
	}

	auto entities = data["Entities"];
	if (entities)
	{
		for (auto entity : entities)
		{
			uint32_t uuid = entity["Entity"].as<uint32_t>(); //Dont use temp
			FString tag(entity["Tag"].as<std::string>().c_str());

			auto deserializedEntity = world->SpawnActor(AStaticMeshActor::StaticClass());
			deserializedEntity->SetActorLabel(tag);

			auto transformComponent = entity["TransformComponent"];
			if (transformComponent)
			{
				FVector Translation = transformComponent["Translation"].as<FVector4>();
				FQuat Rotation = transformComponent["Rotation"].as<FQuat>();
				FVector Scale = transformComponent["Scale"].as<FVector4>();

				deserializedEntity->SetActorLocationAndRotation(Translation * 100, Rotation);
				deserializedEntity->SetActorScale3D(Scale);
			}

			auto rendererComponent = entity["RendererComponent"];
			if (rendererComponent)
			{
				int mesh_type = rendererComponent["Type"].as<int>();
				if (mesh_type > 0)
					((UStaticMeshComponent*)deserializedEntity->GetRootComponent())->SetStaticMesh(primitive_meshes[mesh_type - 1]);
				if (mesh_type == 2)
				{
					deserializedEntity->SetActorScale3D(deserializedEntity->GetActorScale3D() * 10);
				}
			}

			//mesh->GetBodySetup()->AggGeom.BoxElems[0].
		/*auto boxColliderComponent = entity["BoxColliderComponent"];
		if (boxColliderComponent)
		{
			auto& bcc = deserializedEntity->AddComponent<BoxColliderComponent>(deserializedEntity.get(),
				boxColliderComponent["Position"].as<rp3d::Vector3>(),
				boxColliderComponent["Size"].as<rp3d::Vector3>());
		}*/

			auto rigidbodyComponent = entity["RigidbodyComponent"];
			if (rigidbodyComponent)
			{
				auto* rbc = ((UStaticMeshComponent*)deserializedEntity->GetRootComponent());
				switch (rigidbodyComponent["Type"].as<int>())
				{
				case 0:
					rbc->SetConstraintMode(EDOFMode::SixDOF);
				case 1:
					rbc->SetSimulatePhysics(false);
					break;
				case 2:
					rbc->SetSimulatePhysics(true);
					rbc->SetMobility(EComponentMobility::Movable);
					break;
				}
				rbc->SetEnableGravity(rigidbodyComponent["IsGravityEnabled"].as<bool>());
			}
		}
	}

	return true;
}


