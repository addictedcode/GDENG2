// Copyright Epic Games, Inc. All Rights Reserved.

#include "CustomToolbar.h"
#include "CustomToolbarStyle.h"
#include "CustomToolbarCommands.h"
#include "ToolMenus.h"

static const FName CustomToolbarTabName("CustomToolbar");

#define LOCTEXT_NAMESPACE "FCustomToolbarModule"

void FCustomToolbarModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
	
	FCustomToolbarStyle::Initialize();
	FCustomToolbarStyle::ReloadTextures();

	FCustomToolbarCommands::Register();

	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FCustomToolbarModule::RegisterMenus));
}

void FCustomToolbarModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.

	UToolMenus::UnRegisterStartupCallback(this);

	UToolMenus::UnregisterOwner(this);

	FCustomToolbarStyle::Shutdown();

	FCustomToolbarCommands::Unregister();
}

void FCustomToolbarModule::RegisterMenus()
{
	// Owner will be used for cleanup in call to UToolMenus::UnregisterOwner
	FToolMenuOwnerScoped OwnerScoped(this);

	{
		UToolMenu* Menu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu");
		Menu->AddSubMenu(Menu, "GDENG2", "GDENG2", FText::FromString("GDENG2"));
		UToolMenu* sub_menu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.GDENG2");
		
		FToolMenuSection& Section = sub_menu->FindOrAddSection("Scenes");
		Section.AddMenuEntryWithCommandList(FCustomToolbarCommands::Get().cmd_open_scene, FCustomToolbarCommands::Get().m_CommandList);
		Section.AddMenuEntryWithCommandList(FCustomToolbarCommands::Get().cmd_save_scene, FCustomToolbarCommands::Get().m_CommandList);
	}
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FCustomToolbarModule, CustomToolbar)