// Copyright Epic Games, Inc. All Rights Reserved.

#include "CustomToolbarCommands.h"
#include "FileIOBlueprintLibrary.h"

#define LOCTEXT_NAMESPACE "FCustomToolbarModule"

void FCustomToolbarCommands::RegisterCommands()
{
	m_CommandList = MakeShareable(new FUICommandList);

	UI_COMMAND(cmd_open_scene, "Open Scene", "Open Scene...", EUserInterfaceActionType::Button, FInputGesture());
	m_CommandList->MapAction(cmd_open_scene, FExecuteAction::CreateStatic(&FCustomToolbarCallbacks::OpenScene), FCanExecuteAction());

	UI_COMMAND(cmd_save_scene, "Save Scene", "Save Scene To...", EUserInterfaceActionType::Button, FInputGesture());
	m_CommandList->MapAction(cmd_save_scene, FExecuteAction::CreateStatic(&FCustomToolbarCallbacks::SaveScene), FCanExecuteAction());
}

void FCustomToolbarCallbacks::OpenScene()
{
	TArray<FString> outNames;
	UFileIOBlueprintLibrary::OpenFileDialog("Open Scene...", "", "Scene Files (*.scene)|*.scene", outNames);
	for (const FString& filepath : outNames)
	{
		UFileIOBlueprintLibrary::LoadYAMLFile(filepath);
	}
}

void FCustomToolbarCallbacks::SaveScene()
{
	TArray<FString> outNames;
	UFileIOBlueprintLibrary::SaveFileDialog("Save Scene To...", "", "Scene Files (*.scene)|*.scene", outNames);
	for (const FString& filepath : outNames)
	{
		UFileIOBlueprintLibrary::SaveSceneToYAMLFile(filepath);
	}
}

#undef LOCTEXT_NAMESPACE
