// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Commands/Commands.h"
#include "CustomToolbarStyle.h"

class FCustomToolbarCommands : public TCommands<FCustomToolbarCommands>
{
public:

	FCustomToolbarCommands()
		: TCommands<FCustomToolbarCommands>(
			TEXT("GDENG2"), 
			NSLOCTEXT("GDENG2", "GDENG2", "GDENG2 Editor Plugin"), 
			NAME_None, 
			FCustomToolbarStyle::GetStyleSetName())
	{
	}

	// TCommands<> interface
	virtual void RegisterCommands() override;

public:
	TSharedPtr<class FUICommandList> m_CommandList;
	
	TSharedPtr<FUICommandInfo> cmd_open_scene;
	TSharedPtr<FUICommandInfo> cmd_save_scene;
};

class FCustomToolbarCallbacks
{
public:
	static void OpenScene();
	static void SaveScene();
};
